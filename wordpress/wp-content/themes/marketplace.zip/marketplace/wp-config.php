<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'site1tes_marketplace' );

/** MySQL database username */
define( 'DB_USER', 'site1tes_marketplace' );

/** MySQL database password */
define( 'DB_PASSWORD', '_CqVmzh+1wX-' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'ak|3Q:fq_Er8O$^ab@~r&#[cFHJ|VppkHO_wJTIqc!ej5aMTzBO I7;cEU>~l+]A' );
define( 'SECURE_AUTH_KEY',  '8a0hE9J}pv8|Z<A!k3{+m^y{+C-Wj1P#AH>g 9q0=Tnr>GCM]LE;lBC}wn7`SNkq' );
define( 'LOGGED_IN_KEY',    '!0_&D&@Nm)L!fLr3Et.bn h~R:34,+a1j3{!w-QEj.WTkc{R<4/8i$D,LpEL~@_v' );
define( 'NONCE_KEY',        'J;sJbyw2ZvPm$#MQhFFHr$sRsEhjNlUSqV!6 BNOzL5^<F~c0*x,5::}9&P2/Amh' );
define( 'AUTH_SALT',        '2(N|mN5Ity7.![$$O#FS?K6{fb/+s>b*^B)sJ&Y,JWw|zLs_pc?FwIa[{uM b: 6' );
define( 'SECURE_AUTH_SALT', 'KL?KsN%*MskK:bNwW5%G01& 2_s08A[KfTsDWc= !i>)!-yuhMLug5Y@[|hS3n?6' );
define( 'LOGGED_IN_SALT',   'vo~/0tU+~X_@a]BgMl{<BQ 3,[#=aC?L&j8$uv)*L-ip8YU=Qxkw)DH;5VcM%W_J' );
define( 'NONCE_SALT',       'X&73`O8S<qN`]Kq~^Hy}yMs17xMZT`U{!Z*AbCh qUQ?xq)_z{bvB|wi8O7r7dt ' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', true );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
